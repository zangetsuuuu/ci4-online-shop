<?= $this->extend('layout/users/template'); ?>

<?= $this->section('content'); ?>
<div class="min-h-screen">
    <div class="p-4 sm:ml-64">
        <div class="h-full bg-white rounded-lg p-4 mt-16 md:mt-14">

        </div>
    </div>
</div>
<?= $this->endSection(); ?>
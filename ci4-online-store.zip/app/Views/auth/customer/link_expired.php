<?= $this->extend('layout/customer/template'); ?>

<?= $this->section('content'); ?>
<div class="flex items-center justify-center min-h-screen">
    <div class="container px-4 py-16 md:py-0 md:px-0">
        <div class="w-full max-w-sm p-6 mx-auto bg-white shadow-xl md:p-8 rounded-xl">
            <div class="flex justify-center mb-5 md:mb-6">
                <span class="inline-block p-3 bg-gray-100 rounded-full">
                    <svg class="w-5 h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.17157 5.17157C2 6.34315 2 8.22876 2 12C2 15.7712 2 17.6569 3.17157 18.8284C4.34315 20 6.22876 20 10 20H14C17.7712 20 19.6569 20 20.8284 18.8284C22 17.6569 22 15.7712 22 12C22 8.22876 22 6.34315 20.8284 5.17157C19.6569 4 17.7712 4 14 4H10C6.22876 4 4.34315 4 3.17157 5.17157ZM8 13C8.55228 13 9 12.5523 9 12C9 11.4477 8.55228 11 8 11C7.44772 11 7 11.4477 7 12C7 12.5523 7.44772 13 8 13ZM13 12C13 12.5523 12.5523 13 12 13C11.4477 13 11 12.5523 11 12C11 11.4477 11.4477 11 12 11C12.5523 11 13 11.4477 13 12ZM16 13C16.5523 13 17 12.5523 17 12C17 11.4477 16.5523 11 16 11C15.4477 11 15 11.4477 15 12C15 12.5523 15.4477 13 16 13Z" fill="currentColor" />
                    </svg>
                </span>
            </div>
            <div class="mb-4 space-y-2 text-center text-pretty">
                <h2 class="text-lg font-semibold tracking-wide md:text-xl">Link Reset Password telah Kadaluarsa</h2>
                <p class="text-xs tracking-wide text-gray-500">Silakan request link reset password yang baru melalui email Anda.</p>
            </div>
            <form action="<?= base_url('auth/send-email'); ?>" class="flex justify-center" method="post">
                <input type="hidden" name="username" value="<?= $username; ?>">
                <input type="hidden" name="email" value="<?= $email; ?>">
                <button type="submit" class="w-full btn-primary">Kirim Ulang Email</button>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>
    <script src="<?= base_url('js/flowbite.min.js'); ?>"></script>
    <script src="<?= base_url('js/index.js'); ?>"></script>
</body>
</html>
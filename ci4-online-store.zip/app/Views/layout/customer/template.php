<?= $this->include('layout/customer/header'); ?>

<?= $this->include('layout/customer/logout'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('layout/customer/footer'); ?>

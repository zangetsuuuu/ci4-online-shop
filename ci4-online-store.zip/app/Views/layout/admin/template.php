<?= $this->include('layout/admin/header'); ?>

<?= $this->include('layout/admin/logout'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('layout/admin/footer'); ?>
